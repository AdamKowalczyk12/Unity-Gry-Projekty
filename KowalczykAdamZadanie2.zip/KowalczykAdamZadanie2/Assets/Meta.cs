using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Meta : MonoBehaviour
{
    // Start is called before the first frame update
    //void Start()
    //{
        
    //}

    //// Update is called once per frame
    //void Update()
    //{

    //}
        //private void OnCollisonEnte(Collision collidor2)
        //{
        //    if (collidor2.gameObject.tag == "Player")
        //    {
        //        //if (GameObject.FindGameObjectsWithTag("coin").Length < 4 & GameObject.FindGameObjectsWithTag("enemy").Length < 4)
        //        //{
        //            Destroy(this.gameObject); 
        //        //}      
        //    }
        //}
        
   
}
