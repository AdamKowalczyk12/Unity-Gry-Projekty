using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class teleport : MonoBehaviour
{

    public GameObject Spawn;

    // Start is called before the first frame update
    //void Start()
    //{

    //}

    //// Update is called once per frame
    //void Update()
    //{

    //}


    private void OnCollisionEnter(Collision collidor)
    {
        if (collidor.gameObject.tag == "obstacle" || collidor.gameObject.tag == "enemy")
        {
            this.gameObject.transform.position = Spawn.transform.position;
            //SceneManager.LoadScene(SceneManager.GetActiveScene());
        }

        if (collidor.gameObject.tag == "meta")
        {
            if (GameObject.FindGameObjectsWithTag("coin").Length < 2 & GameObject.FindGameObjectsWithTag("enemy").Length < 3)
            {
               Destroy(this.gameObject);
            }      
        } 
    }
}
