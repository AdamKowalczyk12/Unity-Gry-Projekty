using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class promien : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit promien;

        if(Input.GetKeyDown(KeyCode.X))
        {
            if(Physics.Raycast(transform.position, transform.forward, out promien, 15))
            {
                if (promien.collider.gameObject.tag =="enemy")
                {
                    Destroy(promien.collider.gameObject);
                }
            }
        }
    }
}
