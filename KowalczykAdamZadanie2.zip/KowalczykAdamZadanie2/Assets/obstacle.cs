using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class obstacle : MonoBehaviour
{

    public float szybkosc = 0.1f;
    private int zmianaKierunku = 1;
    private Vector3 ww = new Vector3(1, 0, 0);
 
    // Start is called before the first frame update
    void Start()
    {

    }

    //// Update is called once per frame
    void Update()
    {
        transform.localPosition += ww * szybkosc * zmianaKierunku;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag=="wall")
        {
            ww *= -1;
        }     
    }

}
