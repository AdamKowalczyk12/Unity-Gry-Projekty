using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class promien : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public GameObject Pietro0;
    public GameObject Pietro1;
    public GameObject Pietro2;
    // Update is called once per frame
    void Update()
    {
        RaycastHit promien;

        if (Input.GetKeyDown(KeyCode.X))
        {
            if (Physics.Raycast(transform.position, transform.forward, out promien, 15))
            {
                if (promien.collider.gameObject.tag == "0")
                {
                    this.gameObject.transform.position = Pietro0.transform.position;
                   
                    if (gameObject.tag == "elevator")
                    {
                        gameObject.transform.position = Pietro0.transform.position;
                    
                    }
                }
                if (promien.collider.gameObject.tag == "1")
                {
                    this.gameObject.transform.position = Pietro1.transform.position;
                    if (gameObject.tag == "elevator")
                    {
                        gameObject.transform.position = Pietro1.transform.position;

                    }
                }
                if (promien.collider.gameObject.tag == "2")
                {
                    this.gameObject.transform.position = Pietro2.transform.position;
                    if (gameObject.tag == "elevator")
                    {
                        gameObject.transform.position = Pietro2.transform.position;

                    }
                }
            }
        }
    }
}
