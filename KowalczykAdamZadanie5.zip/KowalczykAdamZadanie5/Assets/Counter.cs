using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Counter : MonoBehaviour
{
    public static Counter instance;
    public TMP_Text countText;
    int counter = 1;
   
    // Start is called before the first frame update
    private void Awake()
    {
        instance = this;
    }
    void Start()
    {

        //int c = GameObject.FindGameObjectsWithTag("NPC").Length;
        //for (int i = 0; i < c; i++)
        //{
        //    counter += 1;
            countText.text = "Agent Counter: " + counter.ToString();
        //}
        //countText.text = "Agent Counter: " + counter.ToString();
    }
    public void AddPoint()
    {
        counter += 1;
        countText.text = "Agent Counter: " + counter.ToString();
    }
    // Update is called once per frame
    //void Update()
    //{
      
    //}
 
}
